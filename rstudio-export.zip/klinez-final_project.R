####### Set working directory
setwd("/courses/STA145/klinez")

####### Upload data
library(readr)
data <- read_csv("data.csv")

####### Descriptive Statistics
# qual var
table(data$qual_var)

# quant var
summary(data$quant_var)

# box plot
boxplot(data$quantvar)

# anova
anova <- aov(quant_var ~ qual_var, data = data)

# Analyze assumptions o anova

math_scores$difference <- math_scores$score - mean(math_scores$score)

plot3 <- ggplot(math_scores, aes(x = teaching_method, y = difference, color = teaching_method)) + 
  geom_point(size = 3) +
  ggtitle("Math Scores Deviation by Teaching Method") +
  ylab("Deviation from Mean Score")
print(plot3)
